package com.Assignment.candidate;

public class Candidate {
	 private String name;
	    private int voteCount;
//		public Candidate() {
//			super();
//			// TODO Auto-generated constructor stub
//		}
		
		public Candidate(String name, int voteCount) {
			super();
			this.name = name;
			this.voteCount = voteCount;
		}
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}
		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * @return the voteCount
		 */
		public int getVoteCount() {
			return voteCount;
		}
		/**
		 * @param voteCount the voteCount to set
		 */
		public void setVoteCount(int voteCount) {
			this.voteCount = voteCount;
		}
}
