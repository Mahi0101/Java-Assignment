package com.Assignment.Mycontroller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Assignment.candidate.Candidate;

import java.util.ArrayList;
import java.util.List;



@RestController
public class VotingController {
	private List<Candidate> candidates = new ArrayList<>();

	   @GetMapping("/entercandidate")
	    public void enterCandidate(@RequestParam String name) {
	        // Check if the candidate already exists, if not, add a new candidate
	        if (getCandidateByName(name) == null) {
	            candidates.add(new Candidate(name, 0));
	        }
	    }

	    @PostMapping("/castvote")
	    public int castVote(@RequestParam String name) {
	        Candidate candidate = getCandidateByName(name);
	        if (candidate != null) {
	            candidate.setVoteCount(candidate.getVoteCount() + 1);
	            return candidate.getVoteCount();
	        }
	        return -1; // Candidate not found
	    }

	    @GetMapping("/countvote")
	    public int countVote(@RequestParam String name) {
	        Candidate candidate = getCandidateByName(name);
	        return (candidate != null) ? candidate.getVoteCount() : -1; // Candidate not found
	    }

	    @GetMapping("/listvote")
	    public ResponseEntity<List<Candidate>> listVote() {
	    	return ResponseEntity.ok(candidates);
	    }

	    @GetMapping("/getwinner")
	    public String getWinner() {
	        Candidate winner = candidates.stream()
	                .max((c1, c2) -> Integer.compare(c1.getVoteCount(), c2.getVoteCount()))
	                .orElse(null);
	        return (winner != null) ? winner.getName() : "No winner yet";
	    }

	    private Candidate getCandidateByName(String name) {
	        return candidates.stream()
	                .filter(candidate -> candidate.getName().equals(name))
	                .findFirst()
	                .orElse(null);
	    }
	}

