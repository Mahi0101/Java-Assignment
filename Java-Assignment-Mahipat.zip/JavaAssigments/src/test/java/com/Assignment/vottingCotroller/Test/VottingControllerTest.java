package com.Assignment.vottingCotroller.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.Assignment.Mycontroller.VotingController;
import com.Assignment.candidate.Candidate;


@SpringBootTest
public class VottingControllerTest {
	@Mock
    private List<Candidate> candidates;

    @InjectMocks
    private VotingController votingController;

    @BeforeAll
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testListVote() {
        Candidate candidate1 = new Candidate("Candidate1", 5);
        Candidate candidate2 = new Candidate("Candidate2", 8);

        when(candidates).thenReturn(Arrays.asList(candidate1, candidate2));

        ResponseEntity<List<Candidate>> response = votingController.listVote();

        assertEquals(2, response.getBody().size());
       
    }

}

